x = randomGenerator(0,2000,500)-1000;
nbins = 100;
h = histogram(x,nbins);
avg_var_std(x);
 
