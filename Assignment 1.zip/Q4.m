p0=@(x) 1;
p1=@(x) x;
p2=@(x) 0.5*(3*x.^2-1);
p3=@(x) 0.5*(5*x.^3-3*x);
p4=@(x) 0.125*(35*x.^4 - 30*x.^2 + 3);
p5=@(x) 0.125*(63*x.^5 - 70*x.^3 +15*x);
f=@(x) sin(x);
a=-pi; b=pi;
n=15; m=6;
x=linspace(a,b,n);
rand_vector = 2*rand(1,n)-1;
y=f(x)+ 0.1*rand_vector.*f(x);
A=zeros(m,n);D=zeros(m,n);
for k=1:n
 A(1,k)=p0(x(k)); A(2,k)=p1(x(k)); A(3,k)=p2(x(k)); A(4,k)=p3(x(k));
 A(5,k)=p4(x(k)); A(6, k) = p5(x(k));
end
B=A*A';
C=A*y';
Aug = [B C];
alpha = gauss(Aug);
t=linspace(a,b,100);
z=alpha(1)*p0(t)+alpha(2)*p1(t)+alpha(3)*p2(t)+alpha(4)*p3(t)...
 +alpha(5)*p4(t)+ alpha(6)*p5(t);
plot(t,z,'linewidth',1.0)
hold on
plot(x,y,'*')
grid on