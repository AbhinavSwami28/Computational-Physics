format short
a = 10;
b = 20;

f1 = @(x,y,z) (sqrt(x^2+y^2) - ((a+b)/2))^2 + z^2 - 5^2; %chose random r=5
f2 = @(x,y,z) x^2 + y^2 + z^2 - 15^2; %chose radius between a and b
f3 = @(x,y,z) x+y+z; % arbitary plane

f1x=@(x,y,z) (2*x*(sqrt(x^2+y^2)-((a+b)/2)))/(sqrt(x^2+y^2));
f1y=@(x,y,z) (2*y*(sqrt(x^2+y^2)-((a+b)/2)))/(sqrt(x^2+y^2));
f1z=@(x,y,z) 2*z;
f2x=@(x,y,z) 2*x; f2y=@(x,y,z) 2*y; f2z=@(x,y,z) 2*z;
f3x=@(x,y,z) 1; f3y=@(x,y,z) 1; f3z=@(x,y,z) 1;
distance=@(x,y) sqrt((x-y)'*(x-y));

x=[-10;1;-6];

epsilon=1.0e-8;

J=[f1x(x(1),x(2),x(3)),f1y(x(1),x(2),x(3)),f1z(x(1),x(2),x(3));...
   f2x(x(1),x(2),x(3)),f2y(x(1),x(2),x(3)),f2z(x(1),x(2),x(3));...
   f3x(x(1),x(2),x(3)),f3y(x(1),x(2),x(3)),f3z(x(1),x(2),x(3))];
 
y=x-J\([f1(x(1),x(2),x(3));f2(x(1),x(2),x(3));f3(x(1),x(2),x(3))]);

d=distance(x,y);
count=1;

 
while d >= epsilon
    
    x=y;
    J=[f1x(x(1),x(2),x(3)),f1y(x(1),x(2),x(3)),f1z(x(1),x(2),x(3));...
    f2x(x(1),x(2),x(3)),f2y(x(1),x(2),x(3)),f2z(x(1),x(2),x(3));...
    f3x(x(1),x(2),x(3)),f3y(x(1),x(2),x(3)),f3z(x(1),x(2),x(3))];
 
    y=x-J\[f1(x(1),x(2),x(3));f2(x(1),x(2),x(3));f3(x(1),x(2),x(3))];
    count=count+1;
    d=distance(x,y);
 
    if count>=100
       break
    end 
    
end

display(y);

disp([f1(y(1),y(2),y(3)),f2(y(1),y(2),y(3)),f3(y(1),y(2),y(3))]);

disp(count);

