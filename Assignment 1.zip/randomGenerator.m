function [X] = randomGenerator(lower_limit,upper_limit,N)
a = 5231;
c = 911;
m = upper_limit - lower_limit;
X = zeros(N,1);
X(1) = upper_limit - 643;
for i = 1:(N-1)
    X(i+1) = mod(a*X(i) + c,m);
    X(i+1) = X(i+1) + lower_limit;
end
histogram(X,100);