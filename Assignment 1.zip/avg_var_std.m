function avg_var_std(x)
  x = x(~isnan(x));
  n = length(x);
  avg = sum(x)/n;
  v = sum((x - avg).^2/(n-1));
  S = sqrt(sum((x - avg).^2/(n-1)));
  disp(['mean = ',num2str(avg),' and standard deviation = ',num2str(S)])
  disp(['variance = ',num2str(v)])
end
