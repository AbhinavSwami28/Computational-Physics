function [x] = q1b_and_c()

N = 500;


x = randomGenerator(0,1000,N);
for i = 1:(N-1)
    for j = 1:N-i
        
        if(x(j) > x(j+1))
            temp = x(j);
            x(j) = x(j+1);
            x(j+1) = temp;
            
        end
    end
end

display(x(1)); %smallest value
display(x(N)); %largest value

avg_var_std(x);