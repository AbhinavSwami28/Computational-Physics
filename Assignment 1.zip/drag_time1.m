function [y_new] = drag_time1(gamma, v_0)
g = 9.81;
gamma_d = gamma;
S_time = @(time)(((v_0 + g./gamma_d).*(1 - exp(-gamma_d.*time)) - g*time)./gamma_d);
Sdash_time = @(time)(((v_0 + g./gamma_d).*(exp(-gamma_d.*time)) - g)./gamma_d);
time = 1;

y_new = time - S_time(time)./Sdash_time(time);
epsilon = 0.0001;
count = 1;
while (abs(y_new - time)>=epsilon)
   time = y_new;
   y_new = time - S_time(time)./Sdash_time(time);
   count = count + 1;
end
y_new;
final_distance = S_time(y_new);
count;