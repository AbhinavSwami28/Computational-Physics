format long
x = 0.271;
L = 2;
V0 = 100;

%named term inside bracket as alpha,not to be confused with other alpha
alpha = 0.4 * L * sqrt(V0*x);
beta = (sqrt(1-x) * sqrt(x) * tan(alpha)) - 1 + x;
gamma = (0.2 * sqrt(V0) * L * x * sqrt(1-x) * sec(alpha)^2) + 1;
 
epsilon = 1.0e-8; %(chosen small vlaue)
y = x * (1 - (beta/gamma));
count=1;

while abs(y - x) >= epsilon
    x = y;
    alpha = 0.4 * L * sqrt(V0*x);
    beta = (sqrt(1-x) * sqrt(x) * tan(alpha)) - 1 + x;
    gamma = (0.2 * sqrt(V0) * L * x * sqrt(1-x) * sec(alpha)^2) + 1;
    y = x * (1 - (beta/gamma));
    
    if count > 100
       break
    end 
    count = count+1;
    %iterations are now counted
end
 
f = sqrt((1-x)/x) - tan(alpha);
disp(y);
disp(f);
disp(count);
